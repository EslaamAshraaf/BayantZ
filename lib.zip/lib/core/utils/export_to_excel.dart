import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:bayantz_flutter_task/Features/attendance/data/models/attendance_model.dart';

class ExcelExporter {
  static Future<String> exportAttendanceToExcel(
      List<AttendanceModel> data, String fileName) async {
    final excel = Excel.createExcel();
    final sheet = excel['Attendance'];

    // 🧾 Add header row
    sheet.appendRow([
      TextCellValue('No'),
      TextCellValue('Date'),
      TextCellValue('Status'),
      TextCellValue('Oncoming'),
      TextCellValue('Leaving'),
      TextCellValue('Break'),
      TextCellValue('Total'),
    ]);

    // 🧍‍♂️ Add data rows
    for (final item in data) {
      sheet.appendRow([
        TextCellValue(item.no),
        TextCellValue(item.date),
        TextCellValue(item.status),
        TextCellValue(item.oncoming),
        TextCellValue(item.leaving),
        TextCellValue(item.breakTime),
        TextCellValue(item.total),
      ]);
    }

    // 📂 Save file locally
    final dir = await getApplicationDocumentsDirectory();
    final outputFile = File('${dir.path}/$fileName.xlsx');
    final bytes = excel.encode();

    if (bytes != null) {
      await outputFile.writeAsBytes(bytes);
    }

    return outputFile.path;
  }
}
